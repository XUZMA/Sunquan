Cross Compiling Erlang/OTP
==========================

See the [$ERL_TOP/HOWTO/INSTALL-CROSS.md][] documentation.


   [$ERL_TOP/HOWTO/INSTALL-CROSS.md]: ../HOWTO/INSTALL-CROSS.md
